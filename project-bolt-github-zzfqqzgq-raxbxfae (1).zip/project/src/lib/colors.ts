export const colors = {
  primary: '#2B63BA',
  textColor: "#4E4E4E",
  secondary: '#F59E0B',
  accent: '#10B981',
  neutral: '#374151',
  base: '#F3F4F6',
}